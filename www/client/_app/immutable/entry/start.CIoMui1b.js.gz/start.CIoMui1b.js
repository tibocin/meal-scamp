import{a as t}from"../chunks/entry.DLTvk-7E.js";export{t as start};
