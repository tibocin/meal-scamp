<script lang="ts">
  import Tracker from "$lib/ui/Tracker.svelte";
</script>

<div class="max-w-5xl mx-auto p-4">
  <Tracker />
</div>
