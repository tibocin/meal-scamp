<script lang="ts">
  import Planner from "$lib/ui/Planner.svelte";
</script>

<div class="max-w-5xl mx-auto p-4">
  <Planner />
</div>
