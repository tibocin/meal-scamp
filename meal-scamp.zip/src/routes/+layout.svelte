<script lang="ts">
  import '$lib/styles.css';
</script>
<slot />
