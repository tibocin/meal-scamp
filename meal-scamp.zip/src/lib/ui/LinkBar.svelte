<nav class="flex items-center justify-between card">
  <div class="font-semibold">🥗 Meal Scamp</div>
  <div class="flex gap-2">
    <a class="btn-outline" href="/meals">Meals</a>
    <a class="btn-outline" href="/planner">Planner</a>
    <a class="btn-outline" href="/tracker">Tracker</a>
    <a class="btn-outline" href="/settings">Settings</a>
  </div>
</nav>
