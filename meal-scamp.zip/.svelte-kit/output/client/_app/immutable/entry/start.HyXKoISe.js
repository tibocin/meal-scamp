import{a as t}from"../chunks/entry.C3sTdg-e.js";export{t as start};
