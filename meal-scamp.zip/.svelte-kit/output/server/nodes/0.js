import * as universal from '../entries/pages/_layout.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.BjbG8ruy.js","_app/immutable/chunks/disclose-version.DCp_vzOs.js","_app/immutable/chunks/runtime.CZevBdSz.js","_app/immutable/chunks/legacy.CCzRbt3j.js"];
export const stylesheets = ["_app/immutable/assets/0.D0ZFz0FG.css"];
export const fonts = [];
