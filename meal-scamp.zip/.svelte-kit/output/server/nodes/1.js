

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.0YTDyqtg.js","_app/immutable/chunks/disclose-version.DCp_vzOs.js","_app/immutable/chunks/runtime.CZevBdSz.js","_app/immutable/chunks/legacy.CCzRbt3j.js","_app/immutable/chunks/render.wbgRJjpq.js","_app/immutable/chunks/events.B4nABk9Y.js","_app/immutable/chunks/lifecycle.Ckdua3kn.js","_app/immutable/chunks/store.DMKBJdM6.js","_app/immutable/chunks/index.BP30Mr1K.js","_app/immutable/chunks/entry.C3sTdg-e.js"];
export const stylesheets = [];
export const fonts = [];
