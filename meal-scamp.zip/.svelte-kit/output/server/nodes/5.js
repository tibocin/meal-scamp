

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/settings/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.BdG1QlkD.js","_app/immutable/chunks/disclose-version.DCp_vzOs.js","_app/immutable/chunks/runtime.CZevBdSz.js","_app/immutable/chunks/legacy.CCzRbt3j.js","_app/immutable/chunks/events.B4nABk9Y.js","_app/immutable/chunks/input._xbV5QZX.js","_app/immutable/chunks/lifecycle.Ckdua3kn.js","_app/immutable/chunks/stores.BlB3g5J4.js","_app/immutable/chunks/index.BP30Mr1K.js"];
export const stylesheets = [];
export const fonts = [];
