import { K as ensure_array_like, O as attr_class, N as attr, G as escape_html, P as attr_style, D as pop, z as push } from "./index.js";
import { b as punches, w as workouts, g as goal } from "./stores.js";
function Tracker($$payload, $$props) {
  push();
  let dates = [];
  function genDates() {
    const s = /* @__PURE__ */ new Date();
    s.setDate(s.getDate() - 3);
    const out = [];
    for (let i = 0; i < 30; i++) {
      const d = new Date(s);
      d.setDate(s.getDate() + i);
      out.push(d.toISOString().slice(0, 10));
    }
    return out;
  }
  dates = genDates();
  let punchMap = {};
  punches.subscribe((v) => punchMap = v);
  let workoutMap = {};
  workouts.subscribe((v) => workoutMap = v);
  let g;
  goal.subscribe((v) => g = v);
  const cats = [
    "Strength",
    "Endurance",
    "Fast-twitch",
    "Core",
    "Flexibility"
  ];
  const each_array = ensure_array_like(dates);
  const each_array_1 = ensure_array_like(dates.slice(-7));
  $$payload.out.push(`<div class="space-y-4"><div class="card"><h3 class="font-semibold mb-2">30-Day Success Punch Card</h3> <div class="grid grid-cols-10 gap-2"><!--[-->`);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let d = each_array[$$index];
    $$payload.out.push(`<button${attr_class(`p-3 rounded border ${punchMap[d] ? "bg-green-500 text-white" : "bg-white"}`)}${attr("title", d)}>✔</button>`);
  }
  $$payload.out.push(`<!--]--></div></div> <div class="card"><h3 class="font-semibold mb-2">Weekly Workout Categories</h3> <div class="text-sm text-gray-600 mb-2">Hit each category at least once per week. Flexible days.</div> <div class="space-y-2"><!--[-->`);
  for (let $$index_2 = 0, $$length = each_array_1.length; $$index_2 < $$length; $$index_2++) {
    let d = each_array_1[$$index_2];
    const each_array_2 = ensure_array_like(cats);
    $$payload.out.push(`<div class="flex items-center gap-2"><div class="w-24 text-xs text-gray-500">${escape_html(d)}</div> <!--[-->`);
    for (let $$index_1 = 0, $$length2 = each_array_2.length; $$index_1 < $$length2; $$index_1++) {
      let c = each_array_2[$$index_1];
      $$payload.out.push(`<button${attr_class(`tag ${(workoutMap[d] || []).includes(c) ? "bg-black text-white" : ""}`)}>${escape_html(c)}</button>`);
    }
    $$payload.out.push(`<!--]--></div>`);
  }
  $$payload.out.push(`<!--]--></div></div> <div class="card"><h3 class="font-semibold mb-2">Goal Tracker</h3> <div class="flex items-center gap-3"><div>Start: ${escape_html(g.start)} lbs</div> <div>Target: ${escape_html(g.target)} lbs</div> <div>Current: <input class="border p-1 w-20" type="number"${attr("value", g.current)}/></div></div> <div class="mt-2 w-full bg-gray-200 h-3 rounded"><div class="bg-black h-3 rounded"${attr_style(`width:${Math.min(100, (g.start - g.current) / (g.start - g.target) * 100)}%`)}></div></div></div></div>`);
  pop();
}
export {
  Tracker as T
};
