import { K as ensure_array_like, G as escape_html, M as maybe_selected, N as attr, D as pop, z as push } from "./index.js";
import { p as plan, m as meals } from "./stores.js";
function Planner($$payload, $$props) {
  push();
  let counts, shopping;
  const days = 7;
  let start = /* @__PURE__ */ new Date();
  let mealMap = {};
  plan.subscribe((v) => mealMap = v);
  function dates() {
    const out = [];
    const s = new Date(start);
    for (let i = 0; i < days; i++) {
      const d = new Date(s);
      d.setDate(s.getDate() + i);
      out.push(d.toISOString().slice(0, 10));
    }
    return out;
  }
  let allMeals = [];
  meals.subscribe((v) => allMeals = v);
  if (allMeals.length === 0) {
    fetch("/api/seed").then((r) => r.json()).then((data) => meals.set(data));
  }
  function getMealsForDate(date) {
    return mealMap[date] || [];
  }
  function getMealName(id) {
    const meal = allMeals.find((x) => x.id === id);
    return meal ? meal.name : id;
  }
  counts = (() => {
    const c = {};
    Object.values(mealMap).forEach((arr) => arr.forEach((m) => {
      c[m] = (c[m] || 0) + 1;
    }));
    return c;
  })();
  shopping = (() => {
    const out = {};
    const mealsById = Object.fromEntries(allMeals.map((m) => [m.id, m]));
    for (const arr of Object.values(mealMap)) {
      for (const id of arr) {
        const m = mealsById[id];
        if (!m) continue;
        for (const ing of m.ingredients) {
          out[ing.name] = (out[ing.name] || 0) + (ing.amount || 0);
        }
      }
    }
    return out;
  })();
  const each_array = ensure_array_like(allMeals);
  const each_array_1 = ensure_array_like(dates());
  const each_array_4 = ensure_array_like(Object.entries(counts));
  const each_array_5 = ensure_array_like(Object.entries(shopping));
  $$payload.out.push(`<div class="space-y-4"><div class="card"><h3 class="font-semibold mb-2">Add Meals to Days</h3> <div class="flex gap-2 flex-wrap"><!--[-->`);
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let m = each_array[$$index];
    $$payload.out.push(`<button class="btn-outline">${escape_html(m.name)}</button>`);
  }
  $$payload.out.push(`<!--]--></div></div> <div class="grid md:grid-cols-2 gap-4"><div class="card"><h3 class="font-semibold mb-2">Plan (7 days)</h3> <!--[-->`);
  for (let $$index_3 = 0, $$length = each_array_1.length; $$index_3 < $$length; $$index_3++) {
    let d = each_array_1[$$index_3];
    const each_array_3 = ensure_array_like(allMeals);
    $$payload.out.push(`<div class="mb-3"><div class="text-sm text-gray-500">${escape_html(d)}</div> <div class="flex flex-wrap gap-2 mt-1">`);
    if (getMealsForDate(d).length === 0) {
      $$payload.out.push("<!--[-->");
      $$payload.out.push(`<span class="tag">No meals yet</span>`);
    } else {
      $$payload.out.push("<!--[!-->");
      const each_array_2 = ensure_array_like(getMealsForDate(d));
      $$payload.out.push(`<!--[-->`);
      for (let i = 0, $$length2 = each_array_2.length; i < $$length2; i++) {
        let id = each_array_2[i];
        $$payload.out.push(`<button class="tag">${escape_html(getMealName(id))} ✕</button>`);
      }
      $$payload.out.push(`<!--]-->`);
    }
    $$payload.out.push(`<!--]--></div> <div class="mt-2"><select class="border p-1"><option value=""${maybe_selected($$payload, "")}>+ Add meal</option><!--[-->`);
    for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
      let m = each_array_3[$$index_2];
      $$payload.out.push(`<option${attr("value", m.id)}${maybe_selected($$payload, m.id)}>${escape_html(m.name)}</option>`);
    }
    $$payload.out.push(`<!--]--></select></div></div>`);
  }
  $$payload.out.push(`<!--]--></div> <div class="card"><h3 class="font-semibold mb-2">Batch Prep Counts</h3> <!--[-->`);
  for (let $$index_4 = 0, $$length = each_array_4.length; $$index_4 < $$length; $$index_4++) {
    let [id, n] = each_array_4[$$index_4];
    $$payload.out.push(`<div class="flex justify-between border-b py-1 text-sm"><span>${escape_html(getMealName(id))}</span> <span class="font-mono">${escape_html(n)}×</span></div>`);
  }
  $$payload.out.push(`<!--]--> <h3 class="font-semibold mt-4 mb-2">Shopping List (aggregated)</h3> <!--[-->`);
  for (let $$index_5 = 0, $$length = each_array_5.length; $$index_5 < $$length; $$index_5++) {
    let [name, amt] = each_array_5[$$index_5];
    $$payload.out.push(`<div class="flex justify-between border-b py-1 text-sm"><span>${escape_html(name)}</span><span class="font-mono">${escape_html(amt)}</span></div>`);
  }
  $$payload.out.push(`<!--]--></div></div></div>`);
  pop();
}
export {
  Planner as P
};
