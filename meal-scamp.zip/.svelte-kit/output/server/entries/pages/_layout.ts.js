const prerender = false;
const ssr = true;
export {
  prerender,
  ssr
};
