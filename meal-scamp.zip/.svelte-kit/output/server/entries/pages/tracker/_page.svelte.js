import "clsx";
import { T as Tracker } from "../../../chunks/Tracker.js";
function _page($$payload) {
  $$payload.out.push(`<div class="max-w-5xl mx-auto p-4">`);
  Tracker($$payload);
  $$payload.out.push(`<!----></div>`);
}
export {
  _page as default
};
