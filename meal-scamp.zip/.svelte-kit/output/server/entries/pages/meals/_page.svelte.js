import { K as ensure_array_like, G as escape_html, D as pop, z as push } from "../../../chunks/index.js";
import { m as meals } from "../../../chunks/stores.js";
function _page($$payload, $$props) {
  push();
  let all = [];
  meals.subscribe((v) => all = v);
  if (all.length === 0) {
    fetch("/api/seed").then((r) => r.json()).then((data) => meals.set(data));
  }
  const each_array = ensure_array_like(all);
  $$payload.out.push(`<div class="max-w-5xl mx-auto p-4 space-y-4"><h1 class="text-2xl font-semibold">Meals</h1> <div class="grid md:grid-cols-2 gap-4"><!--[-->`);
  for (let $$index_3 = 0, $$length = each_array.length; $$index_3 < $$length; $$index_3++) {
    let m = each_array[$$index_3];
    const each_array_1 = ensure_array_like(m.ingredients);
    const each_array_2 = ensure_array_like(m.steps);
    const each_array_3 = ensure_array_like(m.tags);
    $$payload.out.push(`<div class="card"><div class="font-semibold">${escape_html(m.name)}</div> <div class="text-sm text-gray-500">${escape_html(m.mealType)}</div> <div class="mt-2 text-sm">Portions: 🍗 ${escape_html(m.portions.protein_palms)} palms, 🥦 ${escape_html(m.portions.veg_fists)} fists, 🍚 ${escape_html(m.portions.starch_fists)} fists, 🥑 ${escape_html(m.portions.fat_thumbs)} thumbs</div> <div class="mt-2 text-sm"><div class="font-semibold">Ingredients</div> <ul class="list-disc ml-5"><!--[-->`);
    for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
      let ing = each_array_1[$$index];
      $$payload.out.push(`<li>${escape_html(ing.name)} — ${escape_html(ing.amount)} ${escape_html(ing.unit)}</li>`);
    }
    $$payload.out.push(`<!--]--></ul></div> <div class="mt-2 text-sm"><div class="font-semibold">Steps</div> <ol class="list-decimal ml-5"><!--[-->`);
    for (let $$index_1 = 0, $$length2 = each_array_2.length; $$index_1 < $$length2; $$index_1++) {
      let s = each_array_2[$$index_1];
      $$payload.out.push(`<li>${escape_html(s)}</li>`);
    }
    $$payload.out.push(`<!--]--></ol></div> <div class="mt-2 flex gap-2"><!--[-->`);
    for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
      let t = each_array_3[$$index_2];
      $$payload.out.push(`<span class="tag">${escape_html(t)}</span>`);
    }
    $$payload.out.push(`<!--]--></div></div>`);
  }
  $$payload.out.push(`<!--]--></div></div>`);
  pop();
}
export {
  _page as default
};
