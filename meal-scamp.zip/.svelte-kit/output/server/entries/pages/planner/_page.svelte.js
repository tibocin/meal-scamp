import "clsx";
import { P as Planner } from "../../../chunks/Planner.js";
function _page($$payload) {
  $$payload.out.push(`<div class="max-w-5xl mx-auto p-4">`);
  Planner($$payload);
  $$payload.out.push(`<!----></div>`);
}
export {
  _page as default
};
