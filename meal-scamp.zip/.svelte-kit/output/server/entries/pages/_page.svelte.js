import "clsx";
import { D as pop, z as push } from "../../chunks/index.js";
import { P as Planner } from "../../chunks/Planner.js";
import { T as Tracker } from "../../chunks/Tracker.js";
function LinkBar($$payload) {
  $$payload.out.push(`<nav class="flex items-center justify-between card"><div class="font-semibold">🥗 Meal Scamp</div> <div class="flex gap-2"><a class="btn-outline" href="/meals">Meals</a> <a class="btn-outline" href="/planner">Planner</a> <a class="btn-outline" href="/tracker">Tracker</a> <a class="btn-outline" href="/settings">Settings</a></div></nav>`);
}
function _page($$payload, $$props) {
  push();
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("/service-worker.js").catch(() => {
    });
  }
  $$payload.out.push(`<div class="max-w-5xl mx-auto p-4 space-y-4">`);
  LinkBar($$payload);
  $$payload.out.push(`<!----> <div class="grid md:grid-cols-2 gap-4"><div class="card"><h2 class="text-xl font-semibold mb-2">Weekly Planner</h2> `);
  Planner($$payload);
  $$payload.out.push(`<!----></div> <div class="card"><h2 class="text-xl font-semibold mb-2">Success &amp; Workout Tracker</h2> `);
  Tracker($$payload);
  $$payload.out.push(`<!----></div></div></div>`);
  pop();
}
export {
  _page as default
};
