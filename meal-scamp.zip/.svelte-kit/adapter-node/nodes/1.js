

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.4NStSs7m.js","_app/immutable/chunks/scheduler.DYjCt7Qj.js","_app/immutable/chunks/index.DJsOjTB_.js","_app/immutable/chunks/entry.DLTvk-7E.js","_app/immutable/chunks/index.zANXAtWU.js"];
export const stylesheets = [];
export const fonts = [];
