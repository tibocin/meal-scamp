

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/settings/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.ClVwQiQd.js","_app/immutable/chunks/scheduler.DYjCt7Qj.js","_app/immutable/chunks/index.DJsOjTB_.js","_app/immutable/chunks/stores.D1Gm6O95.js","_app/immutable/chunks/index.zANXAtWU.js"];
export const stylesheets = [];
export const fonts = [];
