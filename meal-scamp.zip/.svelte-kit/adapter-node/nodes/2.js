

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.B6Ar94sQ.js","_app/immutable/chunks/scheduler.DYjCt7Qj.js","_app/immutable/chunks/index.DJsOjTB_.js","_app/immutable/chunks/Planner.D0RVH9Om.js","_app/immutable/chunks/each.D6YF6ztN.js","_app/immutable/chunks/stores.D1Gm6O95.js","_app/immutable/chunks/index.zANXAtWU.js","_app/immutable/chunks/Tracker.C5klzPIW.js"];
export const stylesheets = [];
export const fonts = [];
