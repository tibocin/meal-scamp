import { c as create_ssr_component, v as validate_component } from "../../../chunks/ssr.js";
import { T as Tracker } from "../../../chunks/Tracker.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="max-w-5xl mx-auto p-4">${validate_component(Tracker, "Tracker").$$render($$result, {}, {}, {})}</div>`;
});
export {
  Page as default
};
